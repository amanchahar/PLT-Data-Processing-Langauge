external make_primitives : unit -> unit = "ctypes_make_primitives"

let () = make_primitives ()
